<?php
    session_start();
    var_dump($_POST);
    if(isset($_POST['number'])) {
        $id = intval($_POST['number']);
    }else {
        echo 'no';
        exit();
    }

    $dbh = new PDO('pgsql:host=localhost;dbname=postgres', "postgres", "root");

    $remove = $dbh->prepare("DELETE FROM name WHERE id=:id");
    $remove->execute([
        "id" => $id
        ]);
?>
