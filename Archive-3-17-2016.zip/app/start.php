<?php

if (!session_start()) {
    session_start();
}

$dbh = new PDO('pgsql:host=localhost;dbname=postgres', "postgres", "root");

require 'passwords.php';
